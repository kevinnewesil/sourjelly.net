<?php  

	$config['email'] = 'kevin@sourjelly.net';
	$config['saveMail'] = '0';
	$config['input']['input']['name'] = 'input';
	$config['input']['input']['placeholder'] = 'inputplaceholder';
	$config['input']['textarea']['name'] = 'textarea';
	$config['input']['file']['name'] = 'attachement';
	$config['contact_form_submit'] = 'Save';
	$config['captcha'] = '0';
	$config['sticky'] = '0';
	$config['allPages'] = '0';
 
	return $config;