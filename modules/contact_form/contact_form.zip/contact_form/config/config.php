<?php  

	$config['email'] = 'kevin@sourjelly.net';
	$config['saveMail'] = '0';
	$config['input']['input']['name'] = 'slet';
	$config['input']['input']['placeholder'] = 'hoer';
	$config['input']['textarea']['name'] = 'negert';
	$config['input']['file']['name'] = 'beunhaas';
	$config['contact_form_submit'] = 'Save';
	$config['captcha'] = '0';
	$config['sticky'] = '0';
	$config['allPages'] = '0';

	return $config;