<?php

	$content = file_get_contents('../html/settings.html');

	if(isset($_POST['contact_form_submit']) && $_POST['contact_form_submit'] == 'save_contact_form_settings')
	{

	}

	echo $content;