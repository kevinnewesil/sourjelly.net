<?php

	# This is the installer for the portfolio module of Sourjelly.
	# All content and data inside this module belong to Sourjelly and are shareware.
	# This means that all Modules have a price connected to them.

	# Note that the migration script in de root folder is executed automatically by the systeem, and therefor will not be included in the installer.

	# happy use of this module.

	# Team Sourjelly &copy;

	# Start installer code

	# Load and parse all pending modules belonging to this.

	$modulesIncluded = array(
		array('name' => 'newsfeed', 'ext' => 'zip'),
		array('name' => 'contact_form', 'ext' => 'zip'),
	);