<?php

	 

	$config['post']['0']['title'] = 'aaa';
	$config['post']['0']['content'] = '<p>aaa</p>';
 

	 

	$config['post']['1']['title'] = 'test';
	$config['post']['1']['content'] = '<p>test</p>';
 

	 

	$config['post']['2']['title'] = 'a';
	$config['post']['2']['content'] = '';
 

	 

	$config['post']['3']['title'] = 'lol';
	$config['post']['3']['content'] = '<p>lol</p><p><br></p>';
 

	 

	$config['post']['4']['title'] = 'haha';
	$config['post']['4']['content'] = '<p>the game</p>';
 

	 

	$config['post']['5']['title'] = 'news item';
	$config['post']['5']['content'] = 'news item text<br><p><br></p>';
 

	 return $config;