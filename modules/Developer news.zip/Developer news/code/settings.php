<?php

	$content = file_get_contents(MODULES_PATH . "Developer news/html/settings.html");

	return $content;