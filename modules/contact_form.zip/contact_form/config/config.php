<?php  

	$config['email'] = 'kevin@sourjelly.net,alain@sourjelly.net';
	$config['saveMail'] = '10';
	$config['captcha'] = '0';
	$config['sticky'] = '0';
	$config['allPages'] = '0';
 

	 return $config;