<?php  
	 
	$config['email'] = 'kevin@sourjelly.net';
	$config['saveMail'] = '10';
	$config['captcha'] = '1';
	$config['position'] = 'OutsideRightTop';
	$config['sticky'] = '1';
	$config['allPages'] = '1';

	return $config;