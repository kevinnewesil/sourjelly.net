<?php

	DEFINE("EMPTY_FIELD","Please enter all fields before sending. <br>");
	DEFINE("INVALID_EMAIL" , "Please enter a valid e-mail adress");
	DEFINE("STRING_LENGHT", "Please recheck the answers you filled in, one is porpably wrong");