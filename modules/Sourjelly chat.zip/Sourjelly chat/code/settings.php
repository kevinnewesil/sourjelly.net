<?php

	/**
	 * 
	 */

	$content = file_get_contents(MODULES_PATH . "Sourjelly chat/html/settings.html");

	return $content;