<?php

	$content = file_get_contents(MODULES_PATH . 'image_gallery/html/settings.html');

	
	
	return $content;